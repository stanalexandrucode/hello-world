def hello_world():
    pass


message = hello_world()
print(message)
